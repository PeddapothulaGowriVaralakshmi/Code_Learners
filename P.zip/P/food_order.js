// cart working js
if (document .ready State == "loading"){
    document.addEventListener("DOMContentLoaded", ready);
}else {
    ready();
}